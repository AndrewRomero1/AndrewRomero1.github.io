import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";
import React from "react";

const Home: React.FC = () => {
  return <div></div>;
};

export default Home;
